import threading
import time


class TelemetrySender(threading.Thread):
    def __init__(self, ip, port, length, serial_port):
        threading.Thread.__init__(self)
        self.ip = ip
        self.port = port
        self.packet_length = length
        self.serial_port = serial_port

    def run(self):
        print('run')
        while True:
            response = ''
            while self.serial_port.inWaiting() > 0:
                response += self.serial_port.read(1)
                if response.find(u'#') > -1:
                    break
            print('telemetry ' + response)
